package certificadosAdmisionBackend.servicio.impl;


import certificadosAdmisionBackend.dto.EstudianteDto;
import certificadosAdmisionBackend.dto.EstudiantePageResponse;
import certificadosAdmisionBackend.repository.sqlserver.EstudianteRepository;
import certificadosAdmisionBackend.repository.sqlserver.EstudianteNotasRepository;
import certificadosAdmisionBackend.servicio.EstudianteService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstudianteServiceImpl implements EstudianteService {

    private final EstudianteRepository estudianteRepository;
    private final EstudianteNotasRepository estudianteNotasRepository;

    // Constructor con ambos repositorios inyectados
    public EstudianteServiceImpl(
            EstudianteRepository estudianteRepository,
            EstudianteNotasRepository estudianteNotasRepository
    ) {
        this.estudianteRepository = estudianteRepository;
        this.estudianteNotasRepository = estudianteNotasRepository;
    }

    @Override
    public EstudiantePageResponse listarTodosPaginado(int page, int size) {
        List<EstudianteDto> estudiantes = estudianteRepository.buscarTodosPaginado(page, size);

        long totalRegistros = estudianteRepository.contarTotalEstudiantes();
        int totalPages = (int) Math.ceil((double) totalRegistros / size);

        return new EstudiantePageResponse(
                estudiantes,
                page,
                totalPages,
                totalRegistros
        );
    }

    @Override
    public List<EstudianteDto> obtenerNotasPorCodigo(String codigo) {
        return estudianteNotasRepository.buscarNotasPorEstudiante(codigo);
    }


}