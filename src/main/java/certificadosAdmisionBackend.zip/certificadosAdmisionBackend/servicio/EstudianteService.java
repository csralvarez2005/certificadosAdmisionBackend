package certificadosAdmisionBackend.servicio;


import certificadosAdmisionBackend.dto.EstudiantePageResponse;

public interface EstudianteService {

}
