package certificadosAdmisionBackend.dto;

public class CertificadoRequest {

    private String cuerpo;

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }
}
